import pandas as pd
import pickle
import seaborn as sns
import matplotlib.pyplot as plt
deliveries_data = pd.read_csv('deliveries.csv')
matches_data=pd.read_csv('matches.csv')
#merging two datasets
main_data = pd.merge(deliveries_data, matches_data, on='match_id', how='left')
# extras_type- 246795/260920  ----->drop---remove rows/col with missing value (>50% is missing)
main_data.drop('extras_type', axis=1, inplace=True)
# player_dismissed-247970/260920 ---->drop  --remove rows/col with missing value (>50% is missing)
main_data.drop('player_dismissed', axis=1, inplace=True)
# dismissal_kind-247970/260920---->drop --remove rows/col with missing value (>50% is missing)
main_data.drop('dismissal_kind', axis=1, inplace=True)
# fielder -251566/260920----->drop --remove rows/col with missing value (>50% is missing)
main_data.drop('fielder', axis=1, inplace=True)
# method -257274/260920----drop --remove rows/col with missing value (>50% is missing)
main_data.drop('method', axis=1, inplace=True)
# city-12397/260920 --object----mode (to fill categorical column)
main_data.fillna({'city':main_data['city'].mode()[0]},inplace=True)
# player_of_match-490/260920 ---object-----mode (to fill categorical column)
main_data.fillna({'player_of_match':main_data['player_of_match'].mode()[0]},inplace=True)
# winner- 490/260920 --object-----mode (to fill categorical column)
main_data.fillna({'winner':main_data['winner'].mode()[0]},inplace=True)
# result_margin -4124/260920 ---float64-- (numeric col)---skewed---median
main_data.fillna({'result_margin': main_data['result_margin'].median()},inplace=True)
# target_runs- 309/260920 --float64-----mean (numeric col)---uniformily distribution
main_data.fillna({'target_runs': main_data['target_runs'].mean()},inplace=True)
# target_overs - 309/260920 --float64---(numeric col)---skewed---median
main_data.fillna({'target_overs': main_data['target_overs'].median()},inplace=True)
# Convert 'over' and 'ball' to a single count for easier calculation
main_data['ball_count'] = main_data['over'] * 6 + main_data['ball']
# Sorting the data to ensure the rolling operation respects the match and inning progression
main_data.sort_values(by=['match_id', 'inning', 'ball_count'], inplace=True)
# Reset the index to ensure proper rolling calculations
main_data.reset_index(drop=True, inplace=True)
# Calculate rolling totals for both runs and wickets, using the last 30 balls
main_data['score_last_30_balls'] = main_data.groupby(['match_id', 'inning'])['total_runs'].transform(
    lambda x: x.rolling(window=30, min_periods=1).sum())
main_data['wickets_last_30_balls'] = main_data.groupby(['match_id', 'inning'])['is_wicket'].transform(
    lambda x: x.rolling(window=30, min_periods=1).sum())
# Calculate the cumulative score
main_data['cumulative_score'] = main_data.groupby(['match_id', 'inning'])['total_runs'].cumsum()
# Adjust the first 5 overs to just cumulative sum up to that ball
mask = main_data['over'] < 5
main_data.loc[mask, 'score_last_30_balls'] = main_data.loc[mask].groupby(['match_id', 'inning'])['total_runs'].cumsum()
main_data.loc[mask, 'wickets_last_30_balls'] = main_data.loc[mask].groupby(['match_id', 'inning'])['is_wicket'].cumsum()
# Calculate cumulative wickets
main_data['cumulative_wickets'] = main_data.groupby(['match_id', 'inning'])['is_wicket'].cumsum()
# Calculate the cumulative total score for each ball in the innings
main_data['cumulative_score'] = main_data.groupby(['match_id', 'inning'])['total_runs'].cumsum()
# Calculate the final total score for each innings and merge this as 'total_score' for each delivery
final_scores = main_data.groupby(['match_id', 'inning'])['cumulative_score'].max().reset_index()
final_scores.rename(columns={'cumulative_score': 'total_score'}, inplace=True)
main_data = pd.merge(main_data, final_scores, on=['match_id', 'inning'], how='left')
#Removing Unwanted Columns from the dataframe
columns= ['is_wicket','non_striker','bowler','batter','match_id','batsman_runs', 'extra_runs',
'is_wicket','season','toss_winner','result','super_over', 'umpire1', 'umpire2',
'target_overs','venue','player_of_match','team1', 'team2','result_margin', 'target_runs','total_runs','match_type','ball_count','winner','ball']
main_data.drop(columns=columns, axis=1, inplace=True)
main_data.dropna(inplace=True)
# Punjab Kings is the new name of Kings XI Punjab & Delhi Capitals is the new name of Delhi Daredevils

main_data['batting_team'] = main_data['batting_team'].replace({
    'Kings XI Punjab': 'Punjab Kings',
    'Delhi Daredevils': 'Delhi Capitals'
})
# Updating in the bowling team column

main_data['bowling_team'] = main_data['bowling_team'].replace({
    'Kings XI Punjab': 'Punjab Kings',
    'Delhi Daredevils': 'Delhi Capitals'
})
#Updating the Bangalore to Bengaluru
main_data['city'] = main_data['city'].replace({
    'Bangalore': 'Bengaluru'
})
# Keeping only consistent teams
consistent_teams = ['Kolkata Knight Riders', 'Chennai Super Kings', 'Rajasthan Royals',
                    'Mumbai Indians', 'Punjab Kings', 'Royal Challengers Bangalore',
                    'Delhi Capitals', 'Sunrisers Hyderabad','Gujarat Titans','Lucknow Super Giants']
consistent_cities= ['Chandigarh', 'Delhi', 'Mumbai', 'Kolkata', 'Jaipur',
       'Hyderabad', 'Chennai',  'Ahmedabad', 'Cuttack', 'Nagpur', 'Dharamsala',
       'Kochi', 'Indore', 'Visakhapatnam', 'Pune', 'Raipur', 'Ranchi',
        'Rajkot', 'Kanpur', 'Bengaluru',
       'Navi Mumbai', 'Lucknow', 'Guwahati', 'Mohali']
# Converting the column 'date' from string into datetime object
from datetime import datetime
main_data['date'] = main_data['date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d'))
# Feature Engineering
ipl_data=pd.get_dummies(main_data, columns=['batting_team','bowling_team','toss_decision','city'],dtype=int)
# Rearranging the columns accordingly
ipl_data = ipl_data[['inning','date', 'batting_team_Chennai Super Kings', 'batting_team_Delhi Capitals',
       'batting_team_Gujarat Titans', 'batting_team_Kolkata Knight Riders',
       'batting_team_Lucknow Super Giants', 'batting_team_Mumbai Indians',
       'batting_team_Punjab Kings', 'batting_team_Rajasthan Royals',
       'batting_team_Royal Challengers Bangalore',
       'batting_team_Sunrisers Hyderabad', 'bowling_team_Chennai Super Kings',
       'bowling_team_Delhi Capitals', 'bowling_team_Gujarat Titans',
       'bowling_team_Kolkata Knight Riders',
       'bowling_team_Lucknow Super Giants', 'bowling_team_Mumbai Indians',
       'bowling_team_Punjab Kings', 'bowling_team_Rajasthan Royals',
       'bowling_team_Royal Challengers Bangalore',
       'bowling_team_Sunrisers Hyderabad',  'toss_decision_bat',
       'toss_decision_field', 'city_Ahmedabad',
       'city_Bengaluru', 'city_Chandigarh', 'city_Chennai', 'city_Cuttack',
       'city_Delhi', 'city_Dharamsala', 'city_Guwahati', 'city_Hyderabad',
       'city_Indore', 'city_Jaipur', 'city_Kolkata', 'city_Lucknow',
       'city_Mohali', 'city_Mumbai', 'city_Navi Mumbai', 'city_Pune',
       'city_Raipur', 'city_Ranchi', 'city_Visakhapatnam','over',  'score_last_30_balls',
       'wickets_last_30_balls', 'cumulative_score','cumulative_wickets', 'total_score'
       ]]
# Splitting the data to train and test
# Splitting the data into train and test set
x_train = ipl_data.drop(labels='total_score', axis=1)[ipl_data['date'].dt.year <= 2022]
x_test = ipl_data.drop(labels='total_score', axis=1)[ipl_data['date'].dt.year > 2022]
y_train = ipl_data[ipl_data['date'].dt.year <= 2022]['total_score'].values
y_test  = ipl_data[ipl_data['date'].dt.year > 2022]['total_score'].values
# Removing the 'date' column
x_train.drop(labels='date', axis=True, inplace=True)
x_test.drop(labels='date', axis=True, inplace=True)
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.tree import DecisionTreeRegressor
from xgboost import XGBRegressor
models = {
    'LinearRegression': LinearRegression(),
    'Lasso': Lasso(),
    'Ridge': Ridge(),
    'RandomForestRegressor': RandomForestRegressor(),
    'DecisionTreeRegressor': DecisionTreeRegressor(),
    'GradientBoostingRegressor': GradientBoostingRegressor(),
    'XGBRegressor': XGBRegressor(),
    'AdaBoostRegressor': AdaBoostRegressor()
}
results = {}
for name, model in models.items():
    scores = cross_val_score(model, x_train, y_train, scoring='neg_mean_squared_error', cv=10)
    results[name] = np.mean(scores)

# Print the results
for name, score in results.items():
    print(f"{name}: Mean MSE: {-score:.4f}")
best_model = max(results, key=results.get)
print(f"Best model is {best_model} with MSE {results[best_model]:.4f}")
# Retrieve the best model and train it on the entire training dataset
final_model = models[best_model]
final_model.fit(x_train, y_train)
# Save the model to a file using pickle
with open('best_model.pkl', 'wb') as file:
    pickle.dump(final_model, file)
