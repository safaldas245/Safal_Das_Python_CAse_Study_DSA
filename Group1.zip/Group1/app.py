# Importing essential libraries
from flask import Flask, render_template, request
import pickle
import numpy as np

# Load the Random Forest CLassifier model
filename = 'best_model.pkl'
best_model = pickle.load(open(filename, 'rb'))

app = Flask(__name__)
@app.route('/')
def home():
 	return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        errors = []
        temp_array = []

        try:
            # Innings
            Innings = int(request.form['Innings'])
            if Innings not in [1, 2]:
                errors.append("Innings must be 1 or 2.")
            temp_array.append(Innings)
        except:
            errors.append("Invalid innings value.")
        
        # Batting Team
        batting_team = request.form['batting-team']
        if batting_team == 'none':
            errors.append("Please select a batting team.")
        else:
            team_encoding = {
                'Chennai Super Kings': [1,0,0,0,0,0,0,0,0,0],
                'Delhi Capitals': [0,1,0,0,0,0,0,0,0,0],
                'Gujarat Titans': [0,0,1,0,0,0,0,0,0,0],
                'Kolkata Knight Riders': [0,0,0,1,0,0,0,0,0,0],
                'Lucknow Super Giants': [0,0,0,0,1,0,0,0,0,0],
                'Mumbai Indians': [0,0,0,0,0,1,0,0,0,0],
                'Punjab Kings': [0,0,0,0,0,0,1,0,0,0],
                'Rajasthan Royals': [0,0,0,0,0,0,0,1,0,0],
                'Royal Challengers Bangalore': [0,0,0,0,0,0,0,0,1,0],
                'Sunrisers Hyderabad': [0,0,0,0,0,0,0,0,0,1]
            }
            temp_array += team_encoding.get(batting_team, [])

        # Bowling Team
        bowling_team = request.form['bowling-team']
        if bowling_team == 'none':
            errors.append("Please select a bowling team.")
        else:
            temp_array += team_encoding.get(bowling_team, [])
        
        batting_team = request.form['batting-team']
        bowling_team = request.form['bowling-team']

        if batting_team == 'none':
         errors.append("Please select a batting team.")
        if bowling_team == 'none':
         errors.append("Please select a bowling team.")
        if batting_team != 'none' and bowling_team != 'none' and batting_team == bowling_team:
         errors.append("Batting and Bowling team cannot be the same.")

        # Toss Decision
        toss_decision = request.form['toss_decision']
        if toss_decision == 'none':
            errors.append("Please select a toss decision.")
        elif toss_decision == 'Bat':
            temp_array += [1, 0]
        elif toss_decision == 'Field':
            temp_array += [0, 1]

        # City
        city = request.form['city']
        if city == 'none':
            errors.append("Please select a city.")
        else:
            city_encoding = {
                'Ahmedabad': [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                'Bengaluru': [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                'Chandigarh': [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                'Chennai': [0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                'Cuttack': [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                'Delhi': [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                'Dharamsala': [0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0],
                'Guwahati': [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0],
                'Hyderabad': [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
                'Indore': [0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0],
                'Jaipur': [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0],
                'Kolkata': [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
                'Lucknow': [0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],
                'Mohali': [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
                'Mumbai': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0],
                'Navi Mumbai': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0],
                'Pune': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0],
                'Raipur': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0],
                'Ranchi': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0],
                'Visakhapatnam': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
            }
            temp_array += city_encoding.get(city, [])

        # Numeric Fields
        try:
            Overs = float(request.form['Overs'])
            if Overs < 5.0:
                errors.append("Overs must be >= 5.0.")
            temp_array.append(Overs)
        except:
            errors.append("Invalid overs input.")

        try:
            Score_in_last_30_balls = int(request.form['Score_in_last_30_balls'])
            temp_array.append(Score_in_last_30_balls)
        except:
            errors.append("Invalid score input.")

        try:
            Wickets_in_last_30_balls = int(request.form['Wickets_in_last_30_balls'])
            if not (0 <= Wickets_in_last_30_balls <= 10):
                errors.append("Wickets in last 30 balls must be between 0 and 10.")
            temp_array.append(Wickets_in_last_30_balls)
        except:
            errors.append("Invalid wickets input.")

        try:
            Current_Total_Score = int(request.form['Current_Total_Score'])
            temp_array.append(Current_Total_Score)
        except:
            errors.append("Invalid total score input.")

        try:
            Wickets_Fallen = int(request.form['Wickets_Fallen'])
            if not (0 <= Wickets_Fallen <= 10):
                errors.append("Wickets fallen must be between 0 and 10.")
            temp_array.append(Wickets_Fallen)
        except:
            errors.append("Invalid total wickets input.")

        # Return errors if any
        if errors:
            return render_template('index.html', error_message="\n".join(errors))

        # Make prediction
        data = np.array([temp_array])
        my_prediction = int(best_model.predict(data)[0])
        return render_template('result.html', lower_limit=my_prediction-10, upper_limit=my_prediction+5)


if __name__ == '__main__':
	app.run(debug=True)